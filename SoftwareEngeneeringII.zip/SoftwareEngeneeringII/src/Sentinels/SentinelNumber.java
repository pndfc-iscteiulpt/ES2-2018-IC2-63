package Sentinels;

import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;

import Components.TextField;

public class SentinelNumber extends KeyAdapter{

	private TextField field;
	
	public SentinelNumber(TextField field) {
		this.field = field;
	}
	
	@Override
	public void keyTyped(KeyEvent e) {
		char c = e.getKeyChar();
		if (!((c >= '0') && (c <= '9') || (c == KeyEvent.VK_BACK_SPACE) || (c == KeyEvent.VK_DELETE))) {
			e.consume();
		}

//		char[] maxNumberOfVariables;
//		if (!field.getText().equals("")
//				&& Integer.parseInt(field.getText()) >= Character
//						.getNumericValue(String.valueOf(maxNumberOfVariables).charAt(0))
//				&& !(c == KeyEvent.VK_BACK_SPACE) && !(c == KeyEvent.VK_DELETE)) {
//			if (Integer.parseInt(field.getText()) < 10
//					|| Integer.parseInt(field.getText() + c) > maxNumberOfVariables)
//				e.consume();
//			field.setText(maxNumberOfVariables + "");
//		}
	}
	
}
