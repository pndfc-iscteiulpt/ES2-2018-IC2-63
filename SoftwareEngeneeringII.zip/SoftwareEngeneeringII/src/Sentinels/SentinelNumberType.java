package Sentinels;

import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;

import javax.swing.JComboBox;
import javax.swing.JOptionPane;
import javax.swing.JTextField;

public class SentinelNumberType extends KeyAdapter {

	private JTextField field;
	private String type;

	public SentinelNumberType(JTextField field, JComboBox<String> variableType) {
		this.field = field;
		this.type = variableType.getItemAt(variableType.getSelectedIndex());
	}
	
	public SentinelNumberType(JTextField field, String type) {
		this.field = field;
		this.type = type;
	}

	@Override
	public void keyTyped(KeyEvent e) {
		char c = e.getKeyChar();
		
		if (!((c == KeyEvent.VK_BACK_SPACE) || (c == KeyEvent.VK_DELETE))) {
			// Integer
			if (type.equals("Integer")) {
				if (!((c >= '0') && (c <= '9') || (c == KeyEvent.VK_MINUS))) {
					e.consume();
				}

				if (!field.getText().equals("") && (c == KeyEvent.VK_MINUS)) {
					try {
						Integer.parseInt(field.getText() + c);
					} catch (NumberFormatException e1) {
						e.consume();
					}
				}
			}

			// Binary
			else if (type.equals("Binary")) {
				if (!((c >= '0') && (c <= '1'))) {
					e.consume();
				}

			}

			// Double
			else if (type.equals("Double")) {
				if (!((c >= '0') && (c <= '9') || (c == KeyEvent.VK_MINUS) || (c == KeyEvent.VK_PERIOD))) {
					e.consume();
				}

				if (!field.getText().equals("") && (c == KeyEvent.VK_MINUS)) {
					try {
						Double.parseDouble(field.getText() + c);
					} catch (NumberFormatException e1) {
						e.consume();
					}
				}

				if (!field.getText().equals("") && (c == KeyEvent.VK_PERIOD)) {
					try {
						Double.parseDouble(field.getText() + c);
					} catch (NumberFormatException e1) {
						e.consume();
					}
				}
			}

			else {
				e.consume();
				JOptionPane.showMessageDialog(null, "Entry Variables Type");
			}
		}
	}

}
