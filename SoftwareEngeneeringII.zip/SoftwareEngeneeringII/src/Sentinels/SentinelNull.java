package Sentinels;

import java.util.List;

import javax.swing.JButton;
import javax.swing.event.CaretEvent;
import javax.swing.event.CaretListener;

import Objects.VariableFields;

public class SentinelNull implements CaretListener {

	private List<VariableFields> variablesList;
	private JButton saveButton;

	public SentinelNull(List<VariableFields> variablesFields, JButton saveButton) {
		this.variablesList = variablesFields;
		this.saveButton = saveButton;
	}

	@Override
	public void caretUpdate(CaretEvent e) {
		boolean saveState = true;

		for (VariableFields variable : variablesList) {
			if (variable.getVariableGroup().getText().equals("")
					|| variable.getVariableType().getSelectedItem().equals("")
					|| variable.getVariableName().getText().equals("")
					|| variable.getVariableMinimum().getText().equals("")
					|| variable.getVariableMaximum().getText().equals("")
					|| variable.getVariableRestrictions().getText().equals("")) {

				saveState = false;
			}
		}

		saveButton.setEnabled(saveState);

	}

}
