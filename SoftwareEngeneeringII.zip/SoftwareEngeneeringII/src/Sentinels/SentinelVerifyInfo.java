package Sentinels;

import java.util.ArrayList;
import java.util.List;

import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;

import Main.Engine;

public class SentinelVerifyInfo {

	private Engine engine = Engine.getInstance();

	private DefaultTableModel modelList;
	private String variablesType;
	private List<String> badVariables;

	public SentinelVerifyInfo(DefaultTableModel model) {
		this.modelList = model;
		variablesType = engine.getVariablesType();
		badVariables = new ArrayList<String>();
	}

	public void start() {
		/*
		 * Verificar o valor singular de cada vari�vel Devolver, eventualmente, um valor
		 * l�gico Resolver consoante o valor l�gico devolvido
		 */

		if (!variablesType.equals("Integer") && !variablesType.equals("Double") && !variablesType.equals("Binary")) {

			JOptionPane.showMessageDialog(null, "Entry Variables Type");

		} else {

			boolean sendWarning = false;

			for (int i = 0; i < modelList.getRowCount(); i++) {
				for (int j = 1; j < modelList.getColumnCount(); j++) {

					int line = i + 1;

					try {

						String value = (String) modelList.getValueAt(i, j);

						if (j >= 2 && !value.equals("")) {

							// Integer
							if (variablesType.equals("Integer")) {
								try {
									Integer.parseInt(value);
								} catch (NumberFormatException e1) {
									badVariables.add(verifyColumn(line, j));
									System.out.println(verifyColumn(line, j));
								}
							}

							// Binary
							else if (variablesType.equals("Binary")) {

								try {
									Integer.parseInt(value);
								} catch (NumberFormatException e1) {
									badVariables.add(verifyColumn(line, j));
									System.out.println(verifyColumn(line, j));
								}

								for (int b = 0; b < value.length(); b++) {
									if (value.charAt(b) == '0' || value.charAt(b) == '1') {

									} else {
										badVariables.add(verifyColumn(line, j));
										System.out.println(verifyColumn(line, j));
									}
								}

							}

							// Double
							else if (variablesType.equals("Double")) {
								try {
									Double.parseDouble(value);
								} catch (NumberFormatException e1) {
									badVariables.add(verifyColumn(line, j));
									System.out.println(verifyColumn(line, j));
								}

							}
						} else {
							badVariables.add(emptyCell(line, j));
							System.out.println(emptyCell(line, j));
						}
					} catch (NullPointerException e) {
						badVariables.add(emptyCell(line, j));
						System.out.println(emptyCell(line, j));
					}
				}

			}

		}

	}

	private String emptyCell(int line, int column) {

		String returning = "Empty:  Line: " + line + " - Field: ";

		if (column == 1) {
			returning += "Variable Name";
		} else if (column == 2) {
			returning += "Minimum";
		} else if (column == 3) {
			returning += "Maximum";
		} else if (column == 4) {
			returning += "Restrictions";
		}

		return returning;
	}

	private String verifyColumn(int line, int column) {

		String returning = "Mistake:  Line: " + line + " - Field: ";

		if (column == 2) {
			returning += "Minimum";
		} else if (column == 3) {
			returning += "Maximum";
		} else if (column == 4) {
			returning += "Restrictions";
		}

		return returning;

	}

}
