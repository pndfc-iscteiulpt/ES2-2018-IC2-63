package GUI;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.WindowConstants;

import Components.Label;
import Components.TextField;

@SuppressWarnings("serial")
public class PrimaryWindow extends JFrame{
	
	private int windowWidth = 600;
	private int windowHeight = 600;
	
	private TextField emailField;

	public PrimaryWindow() {
		// TODO Auto-generated constructor stub
		setTitle("User GUI");
		setLayout(new BorderLayout());
		setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);

	}
	
	public void open() {
		addContent();

//		pack();
		
		setVisible(true);
		
		setSize(windowWidth, windowHeight);
		setResizable(false);

		Dimension dimension = Toolkit.getDefaultToolkit().getScreenSize();

		setLocation((int) (dimension.getWidth() / 2 - windowWidth / 2),
				(int) (dimension.getHeight() / 2 - windowHeight / 2));

	}
	
	private void addContent() {
		/*
		 * Superior Panel || Problem Name
		 */
		JPanel superiorPanel = new JPanel();
		superiorPanel.setLayout(new FlowLayout(FlowLayout.LEFT));
		add(superiorPanel, BorderLayout.NORTH);
		
		// Problem
//		JLabel nameLabel = new JLabel("Problem name: ");
//		nameLabel.setFont(new Font("Arial", Font.BOLD, 30));
//		superiorPanel.add(nameLabel);
		
		Label nameLabel = new Label("Problem name: ",Font.BOLD, 30);
		superiorPanel.add(nameLabel);
		
//		JTextField problemNameField = new JTextField();
//		problemNameField.setFont(new Font("Arial", Font.CENTER_BASELINE, 20));
//		problemNameField.setHorizontalAlignment(JTextField.CENTER);
//		problemNameField.setPreferredSize(new Dimension(300, 30));
//		superiorPanel.add(problemNameField);
		
		TextField problemNameField = new TextField(300, 30, Font.CENTER_BASELINE, 20);
		superiorPanel.add(problemNameField);
		
		/*
		 * Center Panel		|| Description + Email
		 */
		JPanel centerPanel = new JPanel();
		centerPanel.setLayout(new BorderLayout());
		add(centerPanel, BorderLayout.CENTER);
		
		// Description
		Label descriptionLabel = new Label("Description: ", Font.BOLD, 25);
		centerPanel.add(descriptionLabel,BorderLayout.NORTH);
		
		
		JPanel descriptionPanel = new JPanel();
		centerPanel.add(descriptionPanel, BorderLayout.CENTER);
		
		JTextArea descriptionArea = new JTextArea(22,40);
		descriptionArea.setBorder(BorderFactory.createLineBorder(Color.BLACK));
//		descriptionArea.setPreferredSize(new Dimension(550,400));
		descriptionArea.setFont(new Font("Arial", Font.ROMAN_BASELINE, 15));
		descriptionPanel.add(descriptionArea);
		
		JScrollPane scroll = new JScrollPane(descriptionArea);
		descriptionPanel.add(scroll);
		
		// Email
		JPanel emailPanel = new JPanel();
		emailPanel.setLayout(new FlowLayout(FlowLayout.LEFT));
		centerPanel.add(emailPanel, BorderLayout.SOUTH);
		
		Label emailLabel = new Label("Personal Email: ", Font.BOLD,25);
		emailPanel.add(emailLabel, BorderLayout.SOUTH);
		
		emailField = new TextField(300,30,Font.CENTER_BASELINE,20);
		emailPanel.add(emailField,BorderLayout.SOUTH);
		
		/*
		 * Inferior Panel	||
		 */
		
		JPanel inferiorPanel = new JPanel();
		inferiorPanel.setLayout(new BorderLayout());
		add(inferiorPanel, BorderLayout.SOUTH);
		
		// Various Buttons
		JPanel buttonPanel = new JPanel();
		inferiorPanel.add(buttonPanel, BorderLayout.WEST);
		
		// HELP button
		JButton helpButton = new JButton("Help");
		buttonPanel.add(helpButton);
		helpButton.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				
				HelpWindow help = new HelpWindow(helpButton);
				helpButton.setEnabled(false);
				help.open();
				
			}
		});
		
		// SPECS button
		JButton specsButton = new JButton("Specs");
		buttonPanel.add(specsButton);
		specsButton.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent arg0) {
				SpecsWindow specs = new SpecsWindow(specsButton);
				specsButton.setEnabled(false);
				specs.open();
				
			}
		});
		
		// OPTIMIZATION button
		JButton optimizationButton = new JButton("OPTIMIZATION");
		inferiorPanel.add(optimizationButton, BorderLayout.CENTER);
		optimizationButton.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				
			}
		});
		
		// EXIT button
		JPanel exitPanel = new JPanel();
		inferiorPanel.add(exitPanel,BorderLayout.EAST);
		
		JButton exitButton = new JButton("Exit");
		exitPanel.add(exitButton);
		exitButton.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent arg0) {
				
//				dispose();
				System.exit(EXIT_ON_CLOSE);
				
			}
		});
		
	}
	
	
	public String getEmail() {
		return emailField.getText();
	}
	
	public int getScreenWidth() {
		return windowWidth;
	}
	
	public int getScreenHeight() {
		return windowHeight;
	}
	
}
