package GUI;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.GridLayout;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JList;
import javax.swing.JPanel;
import javax.swing.JTextArea;

import Components.TextField;
import Main.Engine;

@SuppressWarnings("serial")
public class HelpWindow extends JFrame {

	private Engine engine = Engine.getInstance();
	private HelpWindow helpWindow = this;
	private JButton helpButton;

	public HelpWindow(JButton helpButton) {
		this.helpButton = helpButton;

		setLayout(new BorderLayout());
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		setUndecorated(true);
	}

	public void open() {
		addContent();

		setVisible(true);

		Dimension dimension = Toolkit.getDefaultToolkit().getScreenSize();

		setSize((int) (dimension.getWidth() / 2 - engine.getPrimaryWindow().getWidth() / 2),
				engine.getPrimaryWindow().getHeight());
		setResizable(false);

		setLocation(0, (int) (dimension.getHeight() / 2 - engine.getPrimaryWindow().getHeight() / 2));

	}

	private void addContent() {
		/*
		 * Superior Panel
		 */
		JPanel superiorPanel = new JPanel();
		add(superiorPanel, BorderLayout.NORTH);

		TextField searchField = new TextField(300, 30, Font.PLAIN, 20);
		superiorPanel.add(searchField);

		JButton searchButton = new JButton("Search");
		superiorPanel.add(searchButton);

		/*
		 * Center Panel
		 */
		JPanel centerPanel = new JPanel();
		centerPanel.setLayout(new GridLayout(2, 0));
		add(centerPanel, BorderLayout.CENTER);

		JList<Object> helpList = new JList<>();
		helpList.setBorder(BorderFactory.createLineBorder(Color.BLACK));
		centerPanel.add(helpList);

		JTextArea helpDescription = new JTextArea();
		helpDescription.setBorder(BorderFactory.createLineBorder(Color.BLACK));
		centerPanel.add(helpDescription);

		/*
		 * Inferior Panel
		 */
		JPanel inferiorPanel = new JPanel();
		inferiorPanel.setLayout(new BorderLayout());
		add(inferiorPanel, BorderLayout.SOUTH);

		// Email Panel
		JPanel askAdminPanel = new JPanel();
		inferiorPanel.add(askAdminPanel, BorderLayout.WEST);

		JButton askAdminButton = new JButton("Ask Administrator");
		askAdminPanel.add(askAdminButton);
		askAdminButton.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				AskAdminWindow window = new AskAdminWindow(helpWindow);
				helpWindow.setEnabled(false);
				window.open();

			}
		});

		// Exit Help
		JPanel exitPanel = new JPanel();
		inferiorPanel.add(exitPanel, BorderLayout.EAST);

		JButton exitButton = new JButton("Exit Help");
		exitPanel.add(exitButton);
		exitButton.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				helpButton.setEnabled(true);
				dispose();

			}
		});

	}

}
