package GUI;

import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.util.List;

import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.ListSelectionModel;
import javax.swing.table.DefaultTableModel;

import Components.Label;
import Components.TextField;
import Main.Engine;
import Objects.VariableFields;
import Sentinels.SentinelNull;
import Sentinels.SentinelVerifyInfo;

@SuppressWarnings("serial")
public class VariableSettingsWindow extends JFrame {

	private Engine engine = Engine.getInstance();

	private SpecsWindow specsWindow;

	private JButton saveButton;
	private JComboBox<String> variableType;
	// private JTable table;
	private DefaultTableModel model;
	private List<VariableFields> variablesFields = new ArrayList<VariableFields>();

	private String[] columnNames = { "N�", "Variable Name", "Minimum", "Maximum", "Restrictions" };
	private String[] varTypeList = { "", "Integer", "Binary", "Double" };

	public VariableSettingsWindow(SpecsWindow specsWindow, int maxNumberOfVariables) {
		this.specsWindow = specsWindow;

		setLayout(new BorderLayout());
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		setUndecorated(true);

		model = new DefaultTableModel(maxNumberOfVariables, 5);
		model.setColumnIdentifiers(columnNames);
		for (int i = 1; i <= maxNumberOfVariables; i++) {
			model.setValueAt(i + "", i - 1, 0);
		}
	}

	public void open() {
		addContent();

		setVisible(true);

		Dimension dimension = Toolkit.getDefaultToolkit().getScreenSize();

		setSize((int) (dimension.getWidth() / 2 - engine.getPrimaryWindow().getWidth() / 2),
				engine.getPrimaryWindow().getHeight() * 4 / 3);
		setResizable(false);

		setLocation((int) (dimension.getWidth() / 2 + engine.getPrimaryWindow().getWidth() / 2),
				(int) (dimension.getHeight() / 2 - engine.getPrimaryWindow().getHeight() / 6
						- engine.getPrimaryWindow().getHeight() / 2));

	}

	private void addContent() {
		/*
		 * Inferior Panel
		 */
		JPanel inferiorPanel = new JPanel();
		inferiorPanel.setLayout(new BorderLayout());
		add(inferiorPanel, BorderLayout.SOUTH);

		// Save
		JPanel savePanel = new JPanel();
		inferiorPanel.add(savePanel, BorderLayout.WEST);

		// Save Button
		saveButton = new JButton("Save Variables Settings");
		savePanel.add(saveButton);
		saveButton.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				
				SentinelVerifyInfo verification = new SentinelVerifyInfo(model);
				verification.start();

			}
		});

		// Cancel
		JPanel cancelPanel = new JPanel();
		inferiorPanel.add(cancelPanel, BorderLayout.EAST);

		JButton cancelButton = new JButton("Cancel");
		cancelPanel.add(cancelButton);
		cancelButton.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				specsWindow.setEnabled(true);
				dispose();

			}
		});

		/*
		 * Superior Panel
		 */
		JPanel superiorPanel = new JPanel();
		superiorPanel.setLayout(new FlowLayout(FlowLayout.LEFT));
		add(superiorPanel, BorderLayout.NORTH);

		Label groupNameLabel = new Label("Problem name: ", Font.CENTER_BASELINE, 20);
		superiorPanel.add(groupNameLabel);

		TextField groupName = new TextField(300, 30, Font.CENTER_BASELINE, 15);
		superiorPanel.add(groupName);
		// groupName.addCaretListener(new SentinelNull());
		groupName.addCaretListener(new SentinelNull(variablesFields, saveButton));

		Label varTypeLabel = new Label(" Type", Font.CENTER_BASELINE, 18);
		superiorPanel.add(varTypeLabel);

		variableType = new JComboBox<String>(varTypeList);
		variableType.setSelectedItem(engine.getVariablesType());
		superiorPanel.add(variableType);
		variableType.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				engine.setVariablesType((String) variableType.getSelectedItem());
				System.out.println(engine.getVariablesType());
			}
		});

		/*
		 * Center
		 */
		JTable table = new JTable() {
			@Override
			public boolean isCellEditable(int row, int column) {
				if (column == 0) {
					return false;
				}
				return true;
			};
		};
		;
		table.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
		table.getTableHeader().setReorderingAllowed(false);
		table.setModel(model);
		add(new JScrollPane(table), BorderLayout.CENTER);

		table.getColumnModel().getColumn(0).setMaxWidth(50);
		// table.getColumnModel().getColumn(0).

	}

}
