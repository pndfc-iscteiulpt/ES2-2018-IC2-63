package GUI;

import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.GridLayout;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;

import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.event.CaretEvent;
import javax.swing.event.CaretListener;

import Components.Button;
import Components.Label;
import Components.TextField;
import Main.Engine;
import Sentinels.SentinelNumberType;

@SuppressWarnings("serial")
public class SpecsWindow extends JFrame {

	private Engine engine = Engine.getInstance();

	private JButton specsButton;

	private SpecsWindow specsWindow = this;
	private String[] time = { "", "minutes", "hours", "days" };
	private TextField varNumberField;
	private Button setVariablesButton;

	public SpecsWindow(JButton specsButton) {
		this.specsButton = specsButton;

		// setTitle("SPECS");
		setLayout(new BorderLayout());
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		setUndecorated(true);
	}

	public void open() {
		addContent();

		setVisible(true);

		Dimension dimension = Toolkit.getDefaultToolkit().getScreenSize();

		setSize((int) (dimension.getWidth() / 2 - engine.getPrimaryWindow().getWidth() / 2),
				engine.getPrimaryWindow().getHeight());
		setResizable(false);

		setLocation((int) (dimension.getWidth() / 2 + engine.getPrimaryWindow().getWidth() / 2),
				(int) (dimension.getHeight() / 2 - engine.getPrimaryWindow().getHeight() / 2));

	}

	private void addContent() {
		/*
		 * Superior Panel
		 */
		JPanel superiorPanel = new JPanel();
		superiorPanel.setLayout(new BorderLayout());
		add(superiorPanel, BorderLayout.NORTH);

		JPanel westPanel = new JPanel();
		westPanel.setLayout(new BorderLayout());
		superiorPanel.add(westPanel, BorderLayout.WEST);

		// Combos Panel
		JPanel combosPanel = new JPanel();
		westPanel.add(combosPanel, BorderLayout.CENTER);

		Label idealTimeLabel = new Label("Ideal Time: ", Font.CENTER_BASELINE, 25);
		combosPanel.add(idealTimeLabel);

		TextField idealTime = new TextField(3, Font.CENTER_BASELINE, 20);
		idealTime.setText(engine.getIdealTime() + "");
		combosPanel.add(idealTime);
		idealTime.addKeyListener(new SentinelNumberType(idealTime, "Integer"));
		idealTime.addCaretListener(new CaretListener() {

			@Override
			public void caretUpdate(CaretEvent arg0) {
				if (!idealTime.getText().equals("")) {
					engine.setIdealTime(Integer.parseInt(idealTime.getText()));
					System.out.println(engine.getIdealTime());
				}

			}
		});

		JComboBox<String> idealTimeType = new JComboBox<>(time);
		idealTimeType.setSelectedItem(engine.getIdealTimeType());
		combosPanel.add(idealTimeType);
		idealTimeType.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				engine.setIdealTimeType((String) idealTimeType.getSelectedItem());
				System.out.println(engine.getIdealTimeType());
			}
		});

		Label maxTimeLabel = new Label("Maximum Time: ", Font.CENTER_BASELINE, 25);
		combosPanel.add(maxTimeLabel);

		TextField maxTime = new TextField(3, Font.CENTER_BASELINE, 20);
		maxTime.setText(engine.getMaxTime() + "");
		combosPanel.add(maxTime);
		maxTime.addKeyListener(new SentinelNumberType(maxTime, "Integer"));
		maxTime.addCaretListener(new CaretListener() {

			@Override
			public void caretUpdate(CaretEvent arg0) {
				if (!maxTime.getText().equals("")) {
					engine.setMaxTime(Integer.parseInt(maxTime.getText()));
					System.out.println(engine.getMaxTime());
				}

			}
		});

		JComboBox<String> maxTimeType = new JComboBox<>(time);
		maxTimeType.setSelectedItem(engine.getMaxTimeType());
		combosPanel.add(maxTimeType);
		maxTimeType.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				engine.setMaxTimeType((String) maxTimeType.getSelectedItem());
				System.out.println(engine.getMaxTimeType());
			}
		});

		/*
		 * Center Panel
		 */
		JPanel centerPanel = new JPanel();
		centerPanel.setLayout(new BorderLayout());
		add(centerPanel, BorderLayout.CENTER);

		JPanel centerSuperiorPanel = new JPanel();
		centerSuperiorPanel.setLayout(new FlowLayout(FlowLayout.LEFT));
		centerPanel.add(centerSuperiorPanel, BorderLayout.NORTH);

		Label varNumberLabel = new Label("Number of Variables: ", Font.CENTER_BASELINE, 25);
		centerSuperiorPanel.add(varNumberLabel);

		varNumberField = new TextField(60, 30, Font.PLAIN, 20);
		varNumberField.setText(engine.getMaxNumberOfVariables() + "");
		centerSuperiorPanel.add(varNumberField);
		varNumberField.addKeyListener(new KeyAdapter() {

			@Override
			public void keyTyped(KeyEvent e) {
				char c = e.getKeyChar();
				if (!((c >= '0') && (c <= '9') || (c == KeyEvent.VK_BACK_SPACE) || (c == KeyEvent.VK_DELETE))) {
					e.consume();
				}

			}

		});
		varNumberField.addCaretListener(new CaretListener() {

			@Override
			public void caretUpdate(CaretEvent e) {
				if (varNumberField.getText().equals("")) {
					engine.setMaxNumberOfVariables(0);
					System.out.println(engine.getMaxNumberOfVariables());
					setVariablesButton.setEnabled(false);
				} else {
					engine.setMaxNumberOfVariables(Integer.parseInt(varNumberField.getText()));
					System.out.println(engine.getMaxNumberOfVariables());
					setVariablesButton.setEnabled(true);
				}

			}
		});

		// Main Buttons
		JPanel mainsButtonPanel = new JPanel();
		mainsButtonPanel.setLayout(new GridLayout(0, 2));
		centerPanel.add(mainsButtonPanel, BorderLayout.CENTER);

		// Set Variables
		setVariablesButton = new Button("Set Variables", Font.CENTER_BASELINE, 30, false);
		mainsButtonPanel.add(setVariablesButton);
		setVariablesButton.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				VariableSettingsWindow varSetWindow = new VariableSettingsWindow(specsWindow,
						Integer.parseInt(varNumberField.getText()));
				specsWindow.setEnabled(false);
				varSetWindow.open();

			}
		});

		// Set Criteria
		Button setCriteriaButton = new Button("Set Criteria", Font.CENTER_BASELINE, 30, true);
		mainsButtonPanel.add(setCriteriaButton);
		setCriteriaButton.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub

			}
		});

		/*
		 * Inferior Panel
		 */
		JPanel inferiorPanel = new JPanel();
		inferiorPanel.setLayout(new BorderLayout());
		add(inferiorPanel, BorderLayout.SOUTH);

		// Upload & Save
		JPanel saveUploadPanel = new JPanel();
		inferiorPanel.add(saveUploadPanel, BorderLayout.WEST);

		// Save Button
		JButton saveButton = new JButton("Save");
		saveUploadPanel.add(saveButton);
		saveButton.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {

			}
		});

		// Upload Button
		JButton uploadButton = new JButton("Upload");
		saveUploadPanel.add(uploadButton);
		uploadButton.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub

			}
		});

		// Exit
		JPanel exitPanel = new JPanel();
		inferiorPanel.add(exitPanel, BorderLayout.EAST);

		JButton exitButton = new JButton("Exit Specifications");
		exitPanel.add(exitButton);
		exitButton.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				specsButton.setEnabled(true);
				dispose();

			}
		});

	}

}
