package GUI;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;

import Components.Label;
import Components.TextField;
import Functions.SendEmail;
import Main.Engine;

@SuppressWarnings("serial")
public class AskAdminWindow extends JFrame {

	private Engine engine = Engine.getInstance();

	private HelpWindow helpWindow;

	public AskAdminWindow(HelpWindow helpWindow) {
		this.helpWindow = helpWindow;

		setTitle("Ask Administrator");
		setLayout(new BorderLayout());
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		setUndecorated(true);
		getRootPane().setBorder(BorderFactory.createLineBorder(Color.BLACK));
		getContentPane().setBackground(new Color(0, 0, 255, 50));
	}

	public void open() {

		addContent();

		setVisible(true);

		Dimension dimension = Toolkit.getDefaultToolkit().getScreenSize();

		setSize((int) (2 * (dimension.getWidth() / 2 - engine.getPrimaryWindow().getWidth() / 2) / 3),
				(int) (2 * (engine.getPrimaryWindow().getHeight()) / 3));
		setResizable(false);

		setLocation((int) ((dimension.getWidth() / 2 - engine.getPrimaryWindow().getWidth() / 2) / 6),
				(int) (dimension.getHeight() / 2 - engine.getPrimaryWindow().getHeight() / 2)
						+ ((engine.getPrimaryWindow().getHeight()) / 6));

	}

	private void addContent() {
		/*
		 * Superior Panel
		 */
		JPanel superiorPanel = new JPanel();
		superiorPanel.setLayout(new FlowLayout(FlowLayout.LEFT));
		add(superiorPanel, BorderLayout.NORTH);

		Label titleLabel = new Label("Title: ", Font.PLAIN, 25);
		superiorPanel.add(titleLabel);

		TextField titleField = new TextField(300, 30, Font.PLAIN, 20);
		superiorPanel.add(titleField);

		/*
		 * Center Panel
		 */
		JPanel centerPanel = new JPanel();
		centerPanel.setLayout(new BorderLayout());
		add(centerPanel, BorderLayout.CENTER);

		// Description
		Label descriptionLabel = new Label("Description: ", Font.PLAIN, 25);
		centerPanel.add(descriptionLabel, BorderLayout.NORTH);

		JPanel descriptionPanel = new JPanel();
		centerPanel.add(descriptionPanel, BorderLayout.CENTER);

		JTextArea descriptionArea = new JTextArea(15, 30);
		descriptionArea.setBorder(BorderFactory.createLineBorder(Color.BLACK));
		descriptionArea.setFont(new Font("Arial", Font.ROMAN_BASELINE, 15));
		descriptionPanel.add(descriptionArea);

		JScrollPane scroll = new JScrollPane(descriptionArea);
		descriptionPanel.add(scroll);

		/*
		 * Inferior Panel
		 */
		JPanel inferiorPanel = new JPanel();
		inferiorPanel.setLayout(new BorderLayout());
		add(inferiorPanel, BorderLayout.SOUTH);

		// Exit Help
		JPanel exitSendPanel = new JPanel();
		inferiorPanel.add(exitSendPanel, BorderLayout.EAST);

		JButton sendButton = new JButton("Send");
		exitSendPanel.add(sendButton);
		sendButton.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				SendEmail email = new SendEmail(Engine.getInstance().getPrimaryWindow().getEmail(), titleField.getText(), descriptionArea.getText());
				email.send();

			}
		});

		JButton exitButton = new JButton("Cancel");
		exitSendPanel.add(exitButton);
		exitButton.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				helpWindow.setEnabled(true);
				dispose();

			}
		});
	}

}
