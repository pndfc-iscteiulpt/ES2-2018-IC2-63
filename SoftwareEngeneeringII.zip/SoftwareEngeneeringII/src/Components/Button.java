package Components;

import java.awt.Font;

import javax.swing.JButton;

@SuppressWarnings("serial")
public class Button extends JButton{

	public Button(String description, boolean enable) {
		setText(description);
		setEnabled(enable);
	}
	
	public Button(String description, int fontType, int fontSize, boolean enable) {
		setText(description);
		setFont(new Font("Arial", fontType, fontSize));
		setEnabled(enable);
	
	}
	
}
