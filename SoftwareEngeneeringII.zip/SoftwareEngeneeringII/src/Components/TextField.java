package Components;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;

import javax.swing.BorderFactory;
import javax.swing.JTextField;

@SuppressWarnings("serial")
public class TextField extends JTextField {

	public TextField(int columns, int fontStyle, int fontSize) {

		setColumns(columns);
		setFont(new Font("Arial", fontStyle, fontSize));
		setHorizontalAlignment(JTextField.CENTER);
		setBorder(BorderFactory.createLineBorder(Color.BLACK));

	}

	public TextField(int width, int height, int fontStyle, int fontSize) {

		setFont(new Font("Arial", fontStyle, fontSize));
		setHorizontalAlignment(JTextField.CENTER);
		setPreferredSize(new Dimension(width, height));
		setBorder(BorderFactory.createLineBorder(Color.BLACK));

	}
}
