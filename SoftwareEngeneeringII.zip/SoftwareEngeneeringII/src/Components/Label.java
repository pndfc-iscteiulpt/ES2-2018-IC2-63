package Components;

import java.awt.Font;

import javax.swing.JLabel;

@SuppressWarnings("serial")
public class Label extends JLabel{

	public Label(String description, int fontType, int fontSize) {
		setText(description);
		setFont(new Font("Arial", fontType, fontSize));
	}
	
}
