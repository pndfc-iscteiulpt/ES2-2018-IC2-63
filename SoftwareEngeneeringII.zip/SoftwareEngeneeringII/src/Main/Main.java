package Main;

public class Main {

	public static void main(String[] args) {
		Engine engine = Engine.getInstance();
		engine.start();

	}

}
