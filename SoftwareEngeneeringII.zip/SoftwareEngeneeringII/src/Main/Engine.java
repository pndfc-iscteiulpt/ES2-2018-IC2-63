package Main;

import java.util.List;

import GUI.PrimaryWindow;
import Objects.VariableFields;

public class Engine {

	public static final Engine INSTANCE = new Engine();
	
	private PrimaryWindow primaryWindow;
	
	private int idealTime = 0;
	private String idealTimeType = "";
	private int maxTime = 0;
	private String maxTimeType = "";
	private int maxNumberOfVariables = 0;
	private String variablesType = "";
	private List<VariableFields> variablesFields;
	
	

	public Engine() {
		// TODO Auto-generated constructor stub
	}
	
	public void start() {
		primaryWindow = new PrimaryWindow();
		primaryWindow.open();

	}
	
	public int getIdealTime() {
		return idealTime;
	}


	public void setIdealTime(int idealTime) {
		this.idealTime = idealTime;
	}


	public String getIdealTimeType() {
		return idealTimeType;
	}


	public void setIdealTimeType(String idealTimeType) {
		this.idealTimeType = idealTimeType;
	}


	public int getMaxTime() {
		return maxTime;
	}


	public void setMaxTime(int maxTime) {
		this.maxTime = maxTime;
	}


	public String getMaxTimeType() {
		return maxTimeType;
	}


	public void setMaxTimeType(String maxTimeType) {
		this.maxTimeType = maxTimeType;
	}

	public int getMaxNumberOfVariables() {
		return maxNumberOfVariables;
	}

	public void setMaxNumberOfVariables(int maxNumberOfVariables) {
		this.maxNumberOfVariables = maxNumberOfVariables;
	}

	public String getVariablesType() {
		return variablesType;
	}


	public void setVariablesType(String variablesType) {
		this.variablesType = variablesType;
	}


	public List<VariableFields> getVariablesFields() {
		return variablesFields;
	}

	public void setVariablesFields(List<VariableFields> variablesFields) {
		this.variablesFields = variablesFields;
	}
	
	public PrimaryWindow getPrimaryWindow(){
		return primaryWindow;
	}
	
	public static Engine getInstance() {
		return INSTANCE;
	}
}
