package Objects;

public class Variable {
	
	private int variableNumber;
	private String variableGroup;
	private String variableName;
	private String variableType;
	private int variableMinimum;
	private int variableMaximum;
	private String variableRestrictions;

	public Variable(int variableNumber, String variableGroup, String variableType, String variableName, int variableMinimum, int variableMaximum, String variableRestrictions) {
		this.variableNumber = variableNumber;
		this.variableGroup = variableGroup;
		this.variableType = variableType;
		this.variableName = variableName;
		this.variableMinimum = variableMinimum;
		this.variableMaximum = variableMaximum;
	}

	public int getVariableNumber() {
		return variableNumber;
	}

	public void setVariableNumber(int variableNumber) {
		this.variableNumber = variableNumber;
	}
	
	public String getVariableGroup() {
		return variableGroup;
	}

	public void setVariableGroup(String variableGroup) {
		this.variableGroup = variableGroup;
	}

	public String getVariableName() {
		return variableName;
	}

	public void setVariableName(String variableName) {
		this.variableName = variableName;
	}

	public String getVariableType() {
		return variableType;
	}

	public void setVariableType(String variableType) {
		this.variableType = variableType;
	}

	public int getVariableMinimum() {
		return variableMinimum;
	}

	public void setVariableMinimum(int variableMinimum) {
		this.variableMinimum = variableMinimum;
	}

	public int getVariableMaximum() {
		return variableMaximum;
	}

	public void setVariableMaximum(int variableMaximum) {
		this.variableMaximum = variableMaximum;
	}

	public String getVariableRestrictions() {
		return variableRestrictions;
	}

	public void setVariableRestrictions(String variableRestrictions) {
		this.variableRestrictions = variableRestrictions;
	}
	
	
	
}
