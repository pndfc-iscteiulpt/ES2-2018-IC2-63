package Objects;

import javax.swing.JComboBox;
import javax.swing.JTextField;

import Components.TextField;

public class VariableFields {

	private int variableNumber;
	private TextField variableGroup;
	private TextField variableName;
	private JComboBox<String> variableType;
	private TextField variableMinimum;
	private TextField variableMaximum;
	private JTextField variableRestrictions;

	public VariableFields(int variableNumber, TextField variableGroup, JComboBox<String> variableType, TextField variableName, TextField variableMinimum, TextField variableMaximum, JTextField variableRestrictions) {
		this.variableNumber = variableNumber;
		this.variableGroup = variableGroup;
		this.variableType = variableType;
		this.variableName = variableName;
		this.variableMinimum = variableMinimum;
		this.variableMaximum = variableMaximum;
		this.variableRestrictions = variableRestrictions;
	}

	public int getVariableNumber() {
		return variableNumber;
	}

	public void setVariableNumber(int variableNumber) {
		this.variableNumber = variableNumber;
	}

	public TextField getVariableGroup() {
		return variableGroup;
	}

	public void setVariableGroup(TextField variableGroup) {
		this.variableGroup = variableGroup;
	}

	public TextField getVariableName() {
		return variableName;
	}

	public void setVariableName(TextField variableName) {
		this.variableName = variableName;
	}

	public JComboBox<String> getVariableType() {
		return variableType;
	}

	public void setVariableType(JComboBox<String> variableType) {
		this.variableType = variableType;
	}

	public TextField getVariableMinimum() {
		return variableMinimum;
	}

	public void setVariableMinimum(TextField variableMinimum) {
		this.variableMinimum = variableMinimum;
	}

	public TextField getVariableMaximum() {
		return variableMaximum;
	}

	public void setVariableMaximum(TextField variableMaximum) {
		this.variableMaximum = variableMaximum;
	}

	public JTextField getVariableRestrictions() {
		return variableRestrictions;
	}

	public void setVariableRestrictions(JTextField variableRestrictions) {
		this.variableRestrictions = variableRestrictions;
	}
	
}
